@extends('layouts.admin')

@section('content')
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row mt-5">
                    <div class="col-6">
                        <h3>રિપોર્ટ</h3>
                    </div>
                    <div class="col-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}"> <i data-feather="home"></i></a>
                            </li>
                            <li class="breadcrumb-item active">રિપોર્ટ</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    @if (session('message'))
                        <div class="alert alert-success">{{ session('message') }}</div>
                    @endif
                    <div class="card">
                        <div class="card-header">
                            <h5>રિપોર્ટ</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6 col-xl-3 col-lg-6">
                                    <a class="sidebar-link " href="{{ url('admin/masik-bachat/report') }}">

                                        <div class="card o-hidden">
                                            <div class="bg-primary b-r-4 card-body">
                                                <div class="media static-top-widget">
                                                    {{-- <div class="align-self-center text-center"><i data-feather="database"></i>
                                                </div> --}}
                                                    <div class="media-body"><span class="m-0"></span>
                                                        <h4 class="mb-0 counter">માસિક બચત રિપોર્ટ
                                                        </h4><i class="icon-bg" data-feather="file"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-sm-6 col-xl-3 col-lg-6">
                                    <a class="sidebar-link " href="{{ url('admin/fix-deposit/report') }}">

                                        <div class="card o-hidden">
                                            <div class="bg-danger b-r-4 card-body">
                                                <div class="media static-top-widget">
                                                    <div class="media-body"><span class="m-0"></span>
                                                        <h4 class="mb-0 counter">ફિક્સ ડિપોઝિટ રિપોર્ટ

                                                        </h4><i class="icon-bg" data-feather="file"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-sm-6 col-xl-3 col-lg-6">
                                    <a class="sidebar-link " href="{{ url('admin/dikari/report') }}">

                                        <div class="card o-hidden">
                                            <div class="bg-primary b-r-4 card-body">
                                                <div class="media static-top-widget">
                                                    <div class="media-body"><span class="m-0"></span>
                                                        <h4 class="mb-0 counter">દીકરી રિપોર્ટ

                                                        </h4><i class="icon-bg" data-feather="file"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-sm-6 col-xl-3 col-lg-6">
                                    <a class="sidebar-link " href="{{ url('admin/emi/report') }}">

                                        <div class="card o-hidden">
                                            <div class="bg-danger b-r-4 card-body">
                                                <div class="media static-top-widget">
                                                    <div class="media-body"><span class="m-0"></span>
                                                        <h4 class="mb-0 counter">EMI લોન રિપોર્ટ

                                                        </h4><i class="icon-bg" data-feather="file"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
